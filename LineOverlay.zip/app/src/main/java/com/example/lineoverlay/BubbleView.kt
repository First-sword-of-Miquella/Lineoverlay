package com.example.lineoverlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

/** The small floating icon. Ring colour shows state: grey = hidden, red = adjust, yellow = locked. */
class BubbleView(context: Context) : View(context) {

    private val d = resources.displayMetrics.density
    private val sizePx = (52 * d).toInt()

    /** 0 = line hidden, 1 = line shown (adjust), 2 = line shown (locked) */
    var state = 0
        set(value) {
            field = value
            invalidate()
        }

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#CC1C1C1E")
        style = Paint.Style.FILL
    }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = 3f * d
        style = Paint.Style.STROKE
    }
    private val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeWidth = 2f * d
        style = Paint.Style.STROKE
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FFD60A")
        style = Paint.Style.FILL
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(sizePx, sizePx)
    }

    override fun onDraw(canvas: Canvas) {
        val r = sizePx / 2f
        canvas.drawCircle(r, r, r - 2 * d, bgPaint)
        ringPaint.color = when (state) {
            0 -> Color.GRAY
            1 -> Color.parseColor("#FF3B30")
            else -> Color.parseColor("#FFD60A")
        }
        canvas.drawCircle(r, r, r - 2 * d, ringPaint)
        canvas.drawLine(r * 0.5f, r * 1.5f, r * 1.5f, r * 0.5f, iconPaint)
        canvas.drawCircle(r * 1.05f, r * 0.95f, 4 * d, dotPaint)
    }
}
