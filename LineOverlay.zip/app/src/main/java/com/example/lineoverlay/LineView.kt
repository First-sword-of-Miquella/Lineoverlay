package com.example.lineoverlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin

/**
 * Full-screen transparent view that draws one long line with a dot on it.
 *
 * Gestures (only in "adjust" mode):
 *  - 1 finger on the line      -> move the line
 *  - 1 finger on the dot       -> slide the dot along the line
 *  - 2 fingers (1st on line)   -> twist to rotate (and move)
 *  - 2 fingers (1st on dot)    -> pinch to resize the dot
 */
class LineView(context: Context) : View(context) {

    private val d = resources.displayMetrics.density

    // ---- Tweak these to taste ----
    private val lineColor = Color.parseColor("#FF3B30")
    private val dotColor = Color.parseColor("#FFD60A")
    private val lineWidth = 2f * d
    private val grabHalfWidth = 32f * d      // invisible grab zone: 64dp thick
    private val minDot = 5f * d
    private val maxDot = 90f * d
    private var dotRadius = 14f * d

    /** true = you can grab the line. false = locked, all touches pass through. */
    var adjustMode = true
        set(value) {
            field = value
            invalidate()
        }

    private var cx = 0f
    private var cy = 0f
    private var angle = 0f        // radians
    private var dotOffset = 0f    // distance of dot from line centre, along the line
    private var half = 0f         // half of the line length
    private var ready = false

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = lineColor
        strokeWidth = lineWidth
        style = Paint.Style.STROKE
    }
    private val haloPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = lineColor
        alpha = 45
        strokeWidth = 12f * d
        style = Paint.Style.STROKE
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = dotColor
        style = Paint.Style.FILL
    }
    private val dotEdgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#222222")
        strokeWidth = 1.5f * d
        style = Paint.Style.STROKE
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        // Line spans the full screen diagonal so it crosses the screen at any angle.
        half = hypot(w.toFloat(), h.toFloat()) / 2f
        if (!ready) {
            cx = w / 2f
            cy = h / 2f
            ready = true
        }
    }

    override fun onDraw(canvas: Canvas) {
        canvas.save()
        canvas.translate(cx, cy)
        canvas.rotate(Math.toDegrees(angle.toDouble()).toFloat())
        if (adjustMode) canvas.drawLine(-half, 0f, half, 0f, haloPaint)
        canvas.drawLine(-half, 0f, half, 0f, linePaint)
        canvas.drawCircle(dotOffset, 0f, dotRadius, dotPaint)
        canvas.drawCircle(dotOffset, 0f, dotRadius, dotEdgePaint)
        canvas.restore()
    }

    // ---------------- Touch handling ----------------

    private enum class Mode { NONE, LINE, DOT, ROTATE, RESIZE }

    private var mode = Mode.NONE
    private var lastX = 0f
    private var lastY = 0f
    private var startDist = 1f
    private var startRadius = 0f
    private var startPtrAngle = 0f
    private var startLineAngle = 0f
    private var startMidX = 0f
    private var startMidY = 0f
    private var startCx = 0f
    private var startCy = 0f

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!adjustMode) return false

        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val dx = e.x - cx
                val dy = e.y - cy
                val along = dx * cos(angle) + dy * sin(angle)
                val across = -dx * sin(angle) + dy * cos(angle)
                val toDot = hypot(along - dotOffset, across)

                mode = when {
                    toDot <= max(dotRadius, 24f * d) -> Mode.DOT
                    abs(across) <= grabHalfWidth && abs(along) <= half -> Mode.LINE
                    else -> Mode.NONE
                }
                if (mode == Mode.NONE) return false
                lastX = e.x
                lastY = e.y
            }

            MotionEvent.ACTION_POINTER_DOWN -> {
                if (e.pointerCount == 2 && (mode == Mode.LINE || mode == Mode.DOT)) {
                    val dx = e.getX(1) - e.getX(0)
                    val dy = e.getY(1) - e.getY(0)
                    if (mode == Mode.DOT) {
                        mode = Mode.RESIZE
                        startDist = max(hypot(dx, dy), 1f)
                        startRadius = dotRadius
                    } else {
                        mode = Mode.ROTATE
                        startPtrAngle = atan2(dy, dx)
                        startLineAngle = angle
                        startMidX = (e.getX(0) + e.getX(1)) / 2f
                        startMidY = (e.getY(0) + e.getY(1)) / 2f
                        startCx = cx
                        startCy = cy
                    }
                }
            }

            MotionEvent.ACTION_MOVE -> {
                when (mode) {
                    Mode.DOT -> {
                        val dx = e.x - cx
                        val dy = e.y - cy
                        dotOffset = (dx * cos(angle) + dy * sin(angle)).coerceIn(-half, half)
                    }
                    Mode.LINE -> {
                        cx += e.x - lastX
                        cy += e.y - lastY
                        lastX = e.x
                        lastY = e.y
                    }
                    Mode.ROTATE -> if (e.pointerCount >= 2) {
                        val dx = e.getX(1) - e.getX(0)
                        val dy = e.getY(1) - e.getY(0)
                        angle = startLineAngle + (atan2(dy, dx) - startPtrAngle)
                        val mx = (e.getX(0) + e.getX(1)) / 2f
                        val my = (e.getY(0) + e.getY(1)) / 2f
                        cx = startCx + (mx - startMidX)
                        cy = startCy + (my - startMidY)
                    }
                    Mode.RESIZE -> if (e.pointerCount >= 2) {
                        val dist = hypot(e.getX(1) - e.getX(0), e.getY(1) - e.getY(0))
                        dotRadius = (startRadius * dist / startDist).coerceIn(minDot, maxDot)
                    }
                    Mode.NONE -> {}
                }
                invalidate()
            }

            MotionEvent.ACTION_POINTER_UP -> {
                if (mode == Mode.ROTATE || mode == Mode.RESIZE) {
                    // One finger left: carry on moving the line without a jump.
                    val remaining = if (e.actionIndex == 0) 1 else 0
                    lastX = e.getX(remaining)
                    lastY = e.getY(remaining)
                    mode = Mode.LINE
                }
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> mode = Mode.NONE
        }
        return true
    }
}
