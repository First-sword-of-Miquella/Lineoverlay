package com.example.lineoverlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.Toast
import kotlin.math.hypot

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var bubble: BubbleView
    private lateinit var line: LineView
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private lateinit var lineParams: WindowManager.LayoutParams

    private var lineShown = false
    private var locked = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startInForeground()

        // Full-screen window for the line. Touches are only caught in adjust mode.
        line = LineView(this)
        lineParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            }
        }

        // Small draggable bubble.
        bubble = BubbleView(this)
        bubbleParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 300
        }
        setupBubbleTouch()
        wm.addView(bubble, bubbleParams)
    }

    private fun setupBubbleTouch() {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var downTime = 0L
        var dragging = false

        bubble.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = bubbleParams.x
                    startY = bubbleParams.y
                    downTime = e.eventTime
                    dragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!dragging && hypot(dx, dy) > slop) dragging = true
                    if (dragging) {
                        bubbleParams.x = startX + dx.toInt()
                        bubbleParams.y = startY + dy.toInt()
                        wm.updateViewLayout(bubble, bubbleParams)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragging) {
                        if (e.eventTime - downTime >= ViewConfiguration.getLongPressTimeout()) {
                            toggleLock()
                        } else {
                            toggleLine()
                        }
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun toggleLine() {
        if (lineShown) {
            wm.removeView(line)
            lineShown = false
        } else {
            applyLockFlags()
            wm.addView(line, lineParams)
            // Re-add the bubble so it stays on top of the (full-screen) line window.
            wm.removeView(bubble)
            wm.addView(bubble, bubbleParams)
            lineShown = true
        }
        updateBubbleState()
    }

    private fun toggleLock() {
        if (!lineShown) {
            Toast.makeText(this, "Show the line first (tap the bubble)", Toast.LENGTH_SHORT).show()
            return
        }
        locked = !locked
        applyLockFlags()
        wm.updateViewLayout(line, lineParams)
        updateBubbleState()
        Toast.makeText(
            this,
            if (locked) "Locked: touches pass through" else "Adjust mode",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun applyLockFlags() {
        line.adjustMode = !locked
        lineParams.flags = if (locked) {
            lineParams.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        } else {
            lineParams.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        }
    }

    private fun updateBubbleState() {
        bubble.state = when {
            !lineShown -> 0
            locked -> 2
            else -> 1
        }
    }

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Floating line", NotificationManager.IMPORTANCE_LOW)
        )
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle("Floating line is running")
            .setContentText("Tap Stop to remove it")
            .addAction(0, "Stop", stopIntent)
            .build()

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        try { if (lineShown) wm.removeView(line) } catch (e: Exception) {}
        try { wm.removeView(bubble) } catch (e: Exception) {}
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL_ID = "floating_line"
        private const val NOTIF_ID = 1
        private const val ACTION_STOP = "com.example.lineoverlay.STOP"
    }
}
